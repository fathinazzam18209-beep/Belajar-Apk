import 'package:finance_tracker/app/app.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('aplikasi tampil dengan 5 tab bottom navigation', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: FinanceTrackerApp()));
    await tester.pumpAndSettle();

    expect(find.byType(NavigationBar), findsOneWidget);
    expect(find.byType(NavigationDestination), findsNWidgets(5));
    expect(find.text('Dashboard'), findsOneWidget);
  });

  testWidgets('berpindah tab menampilkan halaman yang sesuai', (tester) async {
    await tester.pumpWidget(const ProviderScope(child: FinanceTrackerApp()));
    await tester.pumpAndSettle();

    await tester.tap(find.text('Accounts'));
    await tester.pumpAndSettle();
    expect(find.text('Akun'), findsOneWidget);

    await tester.tap(find.text('Analytics'));
    await tester.pumpAndSettle();
    expect(find.text('Analisis'), findsOneWidget);
  });
}
