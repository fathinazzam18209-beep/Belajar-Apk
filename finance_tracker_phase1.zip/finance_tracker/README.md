# Personal Finance Tracker

Aplikasi Android offline-first untuk mencatat, mengelola, dan menganalisis keuangan pribadi.
Spesifikasi: PRD v2.0 (hanya Android, tanpa Web/PWA/backend).

## Stack

Flutter + Dart, Drift (SQLite), Riverpod, go_router, fl_chart, flutter_secure_storage, Material Design 3.

## Status

- **Phase 1 (inisialisasi + GitHub Actions)**: scaffold, tema, routing 5 tab, workflow APK.
- Phase 2 dst: belum dimulai.

## Struktur folder

```
lib/
  app/        # app, tema, router, shell navigasi
  core/       # database, security, utils (diisi mulai Phase 2)
  features/   # home, transactions, add, analytics, accounts
  shared/     # widget bersama
test/
.github/workflows/build-apk.yml
```

## Build APK tanpa laptop

1. Push repo ini ke GitHub (cabang `main`).
2. Buka tab **Actions** > **Build Android APK** > **Run workflow** (bisa dari browser HP).
3. Setelah selesai, buka run tersebut dan unduh artifact `finance-tracker-debug-apk`.
4. Ekstrak ZIP, lalu pasang `app-debug.apk` di Android (izinkan instal dari sumber ini).

Workflow menjalankan: checkout, Flutter SDK, `pub get`, `flutter analyze`, `flutter test`, build debug APK, upload artifact.
Folder `android/` dibuat otomatis oleh workflow jika belum ada.

## Catatan keamanan

Akun lokal hanya berlaku pada perangkat dan instalasi aplikasi terkait. Pemulihan lintas perangkat membutuhkan backup (Phase 9).
APK debug hanya untuk pengujian; APK release bertanda tangan dikonfigurasi terpisah.
