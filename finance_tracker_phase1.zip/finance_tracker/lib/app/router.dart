import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../features/accounts/presentation/accounts_page.dart';
import '../features/add/presentation/add_page.dart';
import '../features/analytics/presentation/analytics_page.dart';
import '../features/home/presentation/home_page.dart';
import '../features/transactions/presentation/transactions_page.dart';
import 'shell.dart';

/// Path rute utama aplikasi.
abstract final class AppRoutes {
  static const home = '/home';
  static const transactions = '/transactions';
  static const add = '/add';
  static const analytics = '/analytics';
  static const accounts = '/accounts';
}

GoRoute _route(String path, Widget page) => GoRoute(
      path: path,
      pageBuilder: (context, state) => NoTransitionPage(child: page),
    );

/// Router dengan bottom navigation 5 tab (PRD v2.0 bagian J).
final routerProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: AppRoutes.home,
    routes: [
      StatefulShellRoute.indexedStack(
        builder: (context, state, shell) => AppShell(shell: shell),
        branches: [
          StatefulShellBranch(
            routes: [_route(AppRoutes.home, const HomePage())],
          ),
          StatefulShellBranch(
            routes: [_route(AppRoutes.transactions, const TransactionsPage())],
          ),
          StatefulShellBranch(
            routes: [_route(AppRoutes.add, const AddPage())],
          ),
          StatefulShellBranch(
            routes: [_route(AppRoutes.analytics, const AnalyticsPage())],
          ),
          StatefulShellBranch(
            routes: [_route(AppRoutes.accounts, const AccountsPage())],
          ),
        ],
      ),
    ],
  );
});
