import 'package:flutter/material.dart';

import '../../../shared/widgets/placeholder_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const PlaceholderPage(
      title: 'Dashboard',
      icon: Icons.home_outlined,
      phaseNote: 'Dashboard dibuat di Phase 5.',
    );
  }
}
