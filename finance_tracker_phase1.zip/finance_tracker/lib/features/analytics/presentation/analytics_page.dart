import 'package:flutter/material.dart';

import '../../../shared/widgets/placeholder_page.dart';

class AnalyticsPage extends StatelessWidget {
  const AnalyticsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const PlaceholderPage(
      title: 'Analisis',
      icon: Icons.bar_chart_outlined,
      phaseNote: 'Laporan dan grafik dibuat di Phase 7.',
    );
  }
}
