import 'package:flutter/material.dart';

import '../../../shared/widgets/placeholder_page.dart';

class AccountsPage extends StatelessWidget {
  const AccountsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const PlaceholderPage(
      title: 'Akun',
      icon: Icons.account_balance_wallet_outlined,
      phaseNote: 'Manajemen akun dibuat di Phase 3.',
    );
  }
}
