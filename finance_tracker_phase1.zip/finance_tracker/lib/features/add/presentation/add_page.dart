import 'package:flutter/material.dart';

import '../../../shared/widgets/placeholder_page.dart';

class AddPage extends StatelessWidget {
  const AddPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const PlaceholderPage(
      title: 'Tambah Transaksi',
      icon: Icons.add_circle_outline,
      phaseNote: 'Form income, expense, dan transfer dibuat di Phase 4.',
    );
  }
}
