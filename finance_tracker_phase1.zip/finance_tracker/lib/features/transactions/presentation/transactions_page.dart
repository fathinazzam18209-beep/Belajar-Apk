import 'package:flutter/material.dart';

import '../../../shared/widgets/placeholder_page.dart';

class TransactionsPage extends StatelessWidget {
  const TransactionsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const PlaceholderPage(
      title: 'Riwayat Transaksi',
      icon: Icons.receipt_long_outlined,
      phaseNote: 'Transaksi dibuat di Phase 4.',
    );
  }
}
